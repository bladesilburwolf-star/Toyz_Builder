package toyz.builder.terrain;

import com.raylib.Raylib.Model;

import java.util.ArrayList;
import java.util.List;

/**
 * Terrain V2 facade — continuous procedural world for Toyz Builder.
 * Title: Temples, Forts & New Terrain System (ChatGPT design / Grok implementation).
 *
 * Logical sampling grid is generation data only — never voxel rendering.
 */
public final class TerrainGenerator {

    public static final class WorldData {
        public WorldConfig config;
        public WaterGenerator water;
        public List<StructureSite> structureSites = new ArrayList<>();
        public List<StructureSite> bridgeSites = new ArrayList<>();
        public Model mesh;
        public float oceanLevel;

        public float heightOnly(float x, float z) {
            TerrainSample s = sample(x, z);
            return s.height;
        }

        public TerrainSample sample(float x, float z) {
            TerrainSample s = new TerrainSample();
            s.x = x;
            s.z = z;
            BiomeGenerator.fillClimate(s, config);
            s.height = LandformGenerator.baseHeight(x, z, config);
            if (water != null) water.apply(s, config);
            // Slope estimate
            float e = 0.75f;
            float h1 = LandformGenerator.baseHeight(x + e, z, config);
            float h2 = LandformGenerator.baseHeight(x - e, z, config);
            float h3 = LandformGenerator.baseHeight(x, z + e, config);
            float h4 = LandformGenerator.baseHeight(x, z - e, config);
            float dx = (h1 - h2) / (2f * e);
            float dz = (h3 - h4) / (2f * e);
            s.slope = (float) Math.sqrt(dx * dx + dz * dz);
            s.flatness = 1f / (1f + s.slope * 4f);
            s.biome = BiomeGenerator.pick(s);
            // Structure suitability: flat, dry, mid elevation, not ocean shelf
            s.structureScore = 0f;
            if (!s.inWater && !s.riverChannel) {
                s.structureScore = s.flatness * 0.5f
                        + (1f - Math.min(1f, s.waterProximity)) * 0.2f
                        + clamp01(1f - Math.abs(s.height - config.heightScale * 0.25f) / config.heightScale) * 0.3f;
                if (s.height < water.oceanLevel + 1.5f) s.structureScore *= 0.3f;
            }
            return s;
        }
    }

    private TerrainGenerator() {}

    public static WorldData generate(WorldConfig cfg) {
        WorldData w = new WorldData();
        w.config = cfg;
        w.water = WaterGenerator.build(cfg);
        w.oceanLevel = w.water.oceanLevel;
        w.structureSites = LandmarkPlacement.findSites(w, cfg.structures ? 12 : 0);
        w.bridgeSites = LandmarkPlacement.findBridgeCrossings(w, cfg.structures ? 8 : 0);
        try {
            w.mesh = TerrainMeshBuilder.build(w);
        } catch (Throwable t) {
            System.err.println("[TerrainV2] mesh build failed: " + t.getMessage());
            t.printStackTrace();
            w.mesh = null;
        }
        System.out.println("[TerrainV2] seed=" + cfg.seed + " type=" + cfg.type
                + " sites=" + w.structureSites.size()
                + " bridges=" + w.bridgeSites.size()
                + " mesh=" + (w.mesh != null));
        return w;
    }

    public static float getHeight(WorldData w, float x, float z) {
        if (w == null) return 0f;
        return w.heightOnly(x, z);
    }

    public static BiomeId getBiome(WorldData w, float x, float z) {
        if (w == null) return BiomeId.MEADOW;
        return w.sample(x, z).biome;
    }

    private static float clamp01(float v) {
        return v < 0f ? 0f : (v > 1f ? 1f : v);
    }
}
