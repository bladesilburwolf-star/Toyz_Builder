package toyz.builder.terrain;

/**
 * One logical sample of the continuous height field (not a voxel cell).
 */
public final class TerrainSample {
    public float x, z;
    public float height;
    public float temperature;
    public float moisture;
    public float continentalness;
    public float erosion;
    public float waterProximity; // 0 = far, 1 = in/near water
    public float slope;
    public float flatness; // 1 = flat
    public float riverProximity;
    public float waterDistance;
    public BiomeId biome;
    public float structureScore;
    public boolean inWater;
    public boolean riverChannel;
}
