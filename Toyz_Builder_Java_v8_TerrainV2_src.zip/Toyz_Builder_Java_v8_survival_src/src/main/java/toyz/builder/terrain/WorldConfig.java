package toyz.builder.terrain;

/**
 * World generation config for Terrain V2 (Temples, Forts & New Terrain System).
 */
public final class WorldConfig {
    public enum WorldType { FLAT, NORMAL, AMPLIFIED }

    public int seed = 0xC0FFEE;
    public WorldType type = WorldType.NORMAL;
    public boolean structures = true;
    /** World extent in world units (square). */
    public float size = 400f;
    /** Logical sample spacing (generation grid — not voxels). */
    public float sampleSpacing = 4f;
    /** Vertical exaggeration. */
    public float heightScale = 16f;
    /** Mesh may use finer spacing than sampleSpacing for render. */
    public float meshSpacing = 4f;

    public WorldConfig() {}

    public WorldConfig(int seed, WorldType type, boolean structures) {
        this.seed = seed;
        this.type = type == null ? WorldType.NORMAL : type;
        this.structures = structures;
    }

    public static WorldConfig fromLegacy(int seed, toyz.builder.Terrain.WorldType wt, boolean structures) {
        WorldType t = WorldType.NORMAL;
        if (wt == toyz.builder.Terrain.WorldType.FLAT) t = WorldType.FLAT;
        else if (wt == toyz.builder.Terrain.WorldType.AMPLIFIED) t = WorldType.AMPLIFIED;
        WorldConfig c = new WorldConfig(seed, t, structures);
        if (t == WorldType.AMPLIFIED) c.heightScale = 28f;
        if (t == WorldType.FLAT) c.heightScale = 2f;
        return c;
    }

    public float minSpacingLike() {
        return size * 0.12f;
    }
}
