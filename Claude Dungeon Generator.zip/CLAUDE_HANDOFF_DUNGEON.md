# TOYZ BUILDER — DUNGEON GENERATOR (test pass)
## AI handoff / session log — 2026-09-26

**Task:** procedural Daggerfall-style dungeon, a few interior layouts, next to Nether in world creation.
**Contributor:** Claude
**File added:** `src/main/java/toyz/builder/DungeonGenerator.java`
**Touches nothing else.** No UI, MapSystem, Terrain, or ToyzBuilder edits in this pass — wiring is left to you since you own that flow.

### What it does
`DungeonGenerator.generate(seed, originX, originZ, ground)` (or with an explicit
`DungeonGenerator.LayoutType`) returns a `Result` — `pieces`, `spawners`,
`markers`, `entranceX/entranceZ` — same shape as `StructureGenerator.Result`.
Everything is built from pieces that already exist: `BlockStone` walls/ceiling,
`Door` thresholds, `TechLight` braziers. No new models or textures needed.

Three layouts, auto-picked from the seed unless you pass one explicitly:
- **GRID** — lattice of 6–9 chamber rooms, randomized spanning tree of
  L-shaped corridors + a couple of loop links. Classic block-dungeon feel.
- **BSP** — recursive space partition, one irregular room per leaf, siblings
  linked going back up the tree.
- **RADIAL** — central hub room, 5–7 corridor spokes to peripheral rooms
  (last spoke is a larger "vault"), one ring link between two spokes.

Rooms/corridors sit on a 13×13 cell grid (3 world units per cell, so ~39×39
footprint), 3-block-tall walls, single ceiling cap layer. Doors are placed
wherever a corridor meets a different room's `roomId`; interior room cells and
corridor-to-corridor cells stay fully open (no wall, no door). A handful of
`Mob.Spawner`s (AHRIMAN/TONBERRY/ICE_WISP/FIRE_SPRITE/NEEDLEKIN, one per room,
skipping the entrance) and sparse `TechLight` braziers are included.

### Integration steps
1. **World-creation menu** (`UI.java`, `drawWorldCreation`): add `"DUNGEON"` to
   the `types` array next to `"NETHER"`.
2. **World type mapping** (`ToyzBuilder.java` ~line 225): the current line
   ```java
   Terrain.WorldType wt = Terrain.WorldType.values()[Math.max(0, Math.min(3, titleMenu.worldTypeIndex))];
   ```
   is ordinal-indexed and caps at 3, so it can't reach `WorldType.DUNGEON`
   (ordinal 11) just by growing the array. Swap to an explicit lookup table,
   e.g. `Terrain.WorldType[] TYPES_FOR_MENU = { FLAT, NORMAL, AMPLIFIED, NETHER, DUNGEON };`
   and index into that instead of `.values()`.
3. **Generation call**: where `wt == Terrain.WorldType.DUNGEON`, call
   `DungeonGenerator.generate(seed, originX, originZ, ground)` and feed the
   result into the map the same way `StructureGenerator.Result` is consumed
   today (`m.pieces.addAll(sr.pieces)`, `registerDoorPortals` as needed,
   `rebuildMapMarkers`). Player spawn should use `entranceX/entranceZ` instead
   of the usual home-seed spawn point.
4. **World sizing**: `Terrain.generateForestTerrain` currently gives
   `WorldType.DUNGEON` a 220-unit continuous heightmap ground (themed, not an
   actual room layout — that's the gap this generator fills). Since the
   generator only needs flat ground to sit on, you may want to shrink that to
   something closer to the generator's own ~40-unit footprint, or keep the
   larger pad if you want room to add more dungeon "wings" later.
5. Optional: wire `ZonePortal.Target.DUNGEON` (already defined, unused) to an
   outdoor structure — e.g. a tomb/crypt entrance piece — so dungeons are
   reachable in-world rather than only from the title menu.

### Suggested next test seeds
Run a handful of seeds through each `LayoutType` explicitly first (bypassing
the auto-pick) to eyeball GRID vs BSP vs RADIAL before wiring the menu, and
confirm doors line up with the 3-wide corridor openings at a couple of
different room sizes.

### Design rule
Same as the temples/forts pass: generated dungeon geometry is ordinary
`Piece.PlacedPiece` data, so it should stay selectable/editable/destroyable
like anything else placed by hand, not turned into a special immutable object.
