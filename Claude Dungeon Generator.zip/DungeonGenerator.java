package toyz.builder;

import com.raylib.Helpers;

import java.util.ArrayList;
import java.util.List;

/**
 * Procedural Daggerfall-style dungeon interiors.
 *
 * Builds an indoor room + corridor layout entirely from existing placed-piece
 * assets (BlockStone walls/ceiling, Door thresholds, TechLight braziers) so a
 * generated dungeon stays an ordinary editable Piece.PlacedPiece list, the
 * same convention StructureGenerator uses for forts/temples/bridges.
 *
 * Three layout grammars, picked per seed so runs feel distinct:
 *  - GRID   : block-lattice rooms on a spanning tree of L-corridors, plus a
 *             couple of extra links for loops. Closest to classic Daggerfall
 *             block dungeons.
 *  - BSP    : recursive space partition, one room per leaf, siblings linked
 *             going back up the tree. Irregular room sizes, roguelike feel.
 *  - RADIAL : a central hub chamber with corridor spokes out to peripheral
 *             rooms, plus one ring link between neighboring spokes. Reads
 *             like a crypt/vault layout.
 *
 * This class is intentionally standalone: it does not touch Terrain, MapSystem
 * or UI. See GROK_HANDOFF_DUNGEON.md for the few lines needed to wire a
 * "DUNGEON" button into the world-creation menu and call generate() from it.
 */
public final class DungeonGenerator {
    private DungeonGenerator() {}

    public enum LayoutType { GRID, BSP, RADIAL }

    public static final class Result {
        public final List<Piece.PlacedPiece> pieces = new ArrayList<>();
        public final List<Mob.Spawner> spawners = new ArrayList<>();
        public final List<WorldMap.Marker> markers = new ArrayList<>();
        public float entranceX, entranceZ;
    }

    private static final int GRID = 13;        // odd: gives RADIAL a true center cell
    private static final float CELL = 3.0f;     // world units per grid cell (corridor width)
    private static final int WALL_HEIGHT = 3;   // blocks tall
    private static final int MARGIN = 1;        // cells left permanently closed at the grid edge

    // ---- deterministic hash, mirrors StructureGenerator.hash ----
    private static float hash(int a, int b, int seed) {
        long h = a * 0x9E3779B97F4A7C15L + b * 0xC2B2AE3D27D4EB4FL
                + seed * 0x165667B19E3779F9L;
        h ^= h >>> 33;
        h *= 0xff51afd7ed558ccdL;
        h ^= h >>> 33;
        return (float) ((h & 0x7fffffffL) / (double) 0x80000000L);
    }

    private static Piece.PlacedPiece piece(Piece.PieceType type, float x, float y, float z,
                                           float rot, Piece.PieceColor color) {
        Piece.PlacedPiece p = new Piece.PlacedPiece();
        p.type = type;
        p.position = Helpers.newVector3(x, y, z);
        p.rotationY = rot;
        p.color = color;
        p.length = Piece.PieceLength.MED;
        return p;
    }

    private static void mark(Result r, String name, WorldMap.MarkerKind kind, float x, float z) {
        r.markers.add(new WorldMap.Marker(name, kind, x, z));
    }

    // =====================================================================
    // Public entry points
    // =====================================================================

    /** Layout is picked deterministically from the seed. */
    public static Result generate(int seed, float originX, float originZ, float ground) {
        LayoutType[] all = LayoutType.values();
        int idx = (int) (hash(seed, 99, seed) * all.length);
        if (idx >= all.length) idx = all.length - 1;
        return generate(seed, all[idx], originX, originZ, ground);
    }

    public static Result generate(int seed, LayoutType layout, float originX, float originZ, float ground) {
        boolean[][] open = new boolean[GRID][GRID];
        int[][] roomId = new int[GRID][GRID];
        for (int[] row : roomId) java.util.Arrays.fill(row, -1);
        List<int[]> rooms = new ArrayList<>(); // {gx, gz, id}; [0]=entrance, last=treasure/boss

        switch (layout) {
            case BSP:    buildBSP(open, roomId, rooms, seed); break;
            case RADIAL: buildRadial(open, roomId, rooms, seed); break;
            default:     buildGrid(open, roomId, rooms, seed); break;
        }

        Result r = new Result();
        buildArchitecture(r, open, roomId, originX, originZ, ground, seed);
        populate(r, rooms, open, originX, originZ, ground, seed);

        int[] entrance = rooms.get(0);
        r.entranceX = originX + cellX(entrance[0]);
        r.entranceZ = originZ + cellX(entrance[1]);
        mark(r, layout.name() + " Dungeon", WorldMap.MarkerKind.DUNGEON, r.entranceX, r.entranceZ);
        return r;
    }

    private static float cellX(int gridIndex) {
        return (gridIndex - GRID / 2) * CELL;
    }

    // =====================================================================
    // Shared carving helpers (grid space, cell indices, no world units yet)
    // =====================================================================

    private static boolean inBounds(int g) {
        return g >= MARGIN && g <= GRID - 1 - MARGIN;
    }

    private static void stampRoom(boolean[][] open, int[][] roomId, int id,
                                  int cx, int cz, int halfW, int halfH) {
        for (int x = cx - halfW; x <= cx + halfW; x++) {
            for (int z = cz - halfH; z <= cz + halfH; z++) {
                if (!inBounds(x) || !inBounds(z)) continue;
                open[x][z] = true;
                roomId[x][z] = id;
            }
        }
    }

    /** L-shaped corridor: straight along x, then straight along z. Leaves roomId untouched (-1). */
    private static void carvePath(boolean[][] open, int x0, int z0, int x1, int z1) {
        int x = x0;
        while (x != x1) {
            if (inBounds(x) && inBounds(z0)) open[x][z0] = true;
            x += Integer.signum(x1 - x);
        }
        int z = z0;
        while (true) {
            if (inBounds(x1) && inBounds(z)) open[x1][z] = true;
            if (z == z1) break;
            z += Integer.signum(z1 - z);
        }
    }

    /** Bresenham line — used for the RADIAL layout so spokes read as straight rays. */
    private static void carveLine(boolean[][] open, int x0, int z0, int x1, int z1) {
        int dx = Math.abs(x1 - x0), dz = -Math.abs(z1 - z0);
        int sx = x0 < x1 ? 1 : -1, sz = z0 < z1 ? 1 : -1;
        int err = dx + dz;
        int x = x0, z = z0;
        while (true) {
            if (inBounds(x) && inBounds(z)) open[x][z] = true;
            if (x == x1 && z == z1) break;
            int e2 = 2 * err;
            if (e2 >= dz) { err += dz; x += sx; }
            if (e2 <= dx) { err += dx; z += sz; }
        }
    }

    // =====================================================================
    // Layout: GRID — lattice of rooms, randomized spanning tree + loops
    // =====================================================================

    private static void buildGrid(boolean[][] open, int[][] roomId, List<int[]> rooms, int seed) {
        int lo = MARGIN + 1, hi = GRID - 2 - MARGIN;
        int[] lattice = {lo, lo + (hi - lo) / 3, lo + 2 * (hi - lo) / 3, hi};
        List<int[]> anchors = new ArrayList<>();
        for (int lx : lattice) for (int lz : lattice) anchors.add(new int[]{lx, lz});

        int roomCount = Math.min(anchors.size(), 6 + (int) (hash(seed, 1, seed) * 4));
        // deterministic shuffle: swap each slot with a hash-picked later slot
        for (int i = anchors.size() - 1; i > 0; i--) {
            int j = (int) (hash(seed, 200 + i, seed) * (i + 1));
            if (j > i) j = i;
            int[] t = anchors.get(i); anchors.set(i, anchors.get(j)); anchors.set(j, t);
        }

        List<int[]> anchorList = anchors.subList(0, roomCount);
        for (int i = 0; i < anchorList.size(); i++) {
            int[] a = anchorList.get(i);
            int half = hash(i, 41, seed) > 0.6f ? 2 : 1; // 3x3 or 5x5 chamber
            stampRoom(open, roomId, i, a[0], a[1], half, half);
            rooms.add(new int[]{a[0], a[1], i});
        }

        // randomized spanning tree: connect each room to an earlier one
        for (int i = 1; i < rooms.size(); i++) {
            int j = (int) (hash(i, 7, seed) * i);
            if (j >= i) j = i - 1;
            int[] a = rooms.get(i), b = rooms.get(j);
            carvePath(open, a[0], a[1], b[0], b[1]);
        }
        // a couple of extra links for loops (Daggerfall dungeons rarely dead-end everywhere)
        int extra = rooms.size() >= 4 ? 2 : 0;
        for (int k = 0; k < extra; k++) {
            int i = (int) (hash(k, 300, seed) * rooms.size());
            int j = (int) (hash(k, 301, seed) * rooms.size());
            if (i == j || i >= rooms.size() || j >= rooms.size()) continue;
            int[] a = rooms.get(i), b = rooms.get(j);
            carvePath(open, a[0], a[1], b[0], b[1]);
        }
    }

    // =====================================================================
    // Layout: BSP — recursive partition, one room per leaf
    // =====================================================================

    private static void buildBSP(boolean[][] open, int[][] roomId, List<int[]> rooms, int seed) {
        int lo = MARGIN + 1, hi = GRID - 2 - MARGIN;
        int[] next = {0};
        splitBSP(open, roomId, rooms, lo, lo, hi, hi, 0, seed, next);
    }

    /** Returns the cell {x,z} of a representative room within this subtree, for the parent to link. */
    private static int[] splitBSP(boolean[][] open, int[][] roomId, List<int[]> rooms,
                                  int x0, int z0, int x1, int z1, int depth, int seed, int[] nextId) {
        int w = x1 - x0, h = z1 - z0;
        boolean leaf = depth >= 3 || w < 4 || h < 4;
        if (leaf) {
            int rw = Math.max(1, w / 2 - 1), rh = Math.max(1, h / 2 - 1);
            int cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
            int id = nextId[0]++;
            stampRoom(open, roomId, id, cx, cz, rw, rh);
            rooms.add(new int[]{cx, cz, id});
            return new int[]{cx, cz};
        }
        boolean splitX = w >= h;
        float t = 0.35f + hash(x0, z0, seed) * 0.3f; // keep both halves usable
        int[] left, right;
        if (splitX) {
            int mid = x0 + Math.round(w * t);
            left = splitBSP(open, roomId, rooms, x0, z0, mid, z1, depth + 1, seed, nextId);
            right = splitBSP(open, roomId, rooms, mid, z0, x1, z1, depth + 1, seed, nextId);
        } else {
            int mid = z0 + Math.round(h * t);
            left = splitBSP(open, roomId, rooms, x0, z0, x1, mid, depth + 1, seed, nextId);
            right = splitBSP(open, roomId, rooms, x0, mid, x1, z1, depth + 1, seed, nextId);
        }
        carvePath(open, left[0], left[1], right[0], right[1]);
        return hash(x0, z1, seed) > 0.5f ? left : right;
    }

    // =====================================================================
    // Layout: RADIAL — hub chamber with corridor spokes, one ring link
    // =====================================================================

    private static void buildRadial(boolean[][] open, int[][] roomId, List<int[]> rooms, int seed) {
        int center = GRID / 2;
        stampRoom(open, roomId, 0, center, center, 2, 2);
        rooms.add(new int[]{center, center, 0});

        int spokes = 5 + (int) (hash(seed, 500, seed) * 3); // 5..7
        int radius = GRID / 2 - MARGIN - 2;
        int[][] peripheral = new int[spokes][2];
        for (int i = 0; i < spokes; i++) {
            float ang = (float) (i * (2 * Math.PI / spokes) + hash(i, 501, seed) * 0.5f);
            int px = center + Math.round((float) Math.cos(ang) * radius);
            int pz = center + Math.round((float) Math.sin(ang) * radius);
            px = Math.max(MARGIN + 1, Math.min(GRID - 2 - MARGIN, px));
            pz = Math.max(MARGIN + 1, Math.min(GRID - 2 - MARGIN, pz));
            peripheral[i] = new int[]{px, pz};

            int id = i + 1;
            int half = i == spokes - 1 ? 2 : 1; // final spoke room is the treasure vault, a bit larger
            stampRoom(open, roomId, id, px, pz, half, half);
            rooms.add(new int[]{px, pz, id});

            int hubEdgeX = center + Math.round((float) Math.cos(ang) * 2);
            int hubEdgeZ = center + Math.round((float) Math.sin(ang) * 2);
            carveLine(open, hubEdgeX, hubEdgeZ, px, pz);
        }
        // one ring link between two neighboring spokes so the loop isn't purely a star
        if (spokes >= 3) {
            carveLine(open, peripheral[0][0], peripheral[0][1], peripheral[1][0], peripheral[1][1]);
        }
    }

    // =====================================================================
    // Architecture: turn the open/roomId grid into walls, ceiling, doors
    // =====================================================================

    private static void buildArchitecture(Result r, boolean[][] open, int[][] roomId,
                                          float originX, float originZ, float ground, int seed) {
        for (int gx = 0; gx < GRID; gx++) {
            for (int gz = 0; gz < GRID; gz++) {
                if (!open[gx][gz]) continue;
                float cx = originX + cellX(gx), cz = originZ + cellX(gz);
                r.pieces.add(piece(Piece.PieceType.BlockStone, cx, ground + WALL_HEIGHT + 0.5f, cz,
                        0, Piece.PieceColor.Natural));

                // walls: any side whose neighbor is out of range or closed
                closeSide(r, open, gx, gz, -1, 0, cx, cz, ground);
                closeSide(r, open, gx, gz, 1, 0, cx, cz, ground);
                closeSide(r, open, gx, gz, 0, -1, cx, cz, ground);
                closeSide(r, open, gx, gz, 0, 1, cx, cz, ground);

                // doors: only check +x/+z so each open-open edge is decided once
                doorSide(r, open, roomId, gx, gz, 1, 0, cx, cz, ground, seed);
                doorSide(r, open, roomId, gx, gz, 0, 1, cx, cz, ground, seed);
            }
        }
    }

    private static void closeSide(Result r, boolean[][] open, int gx, int gz, int dx, int dz,
                                  float cx, float cz, float ground) {
        int nx = gx + dx, nz = gz + dz;
        boolean neighborOpen = nx >= 0 && nx < GRID && nz >= 0 && nz < GRID && open[nx][nz];
        if (neighborOpen) return;
        float edgeX = cx + dx * (CELL / 2f), edgeZ = cz + dz * (CELL / 2f);
        boolean alongZ = dx != 0; // wall spans the z axis when it faces +/-x
        for (int i = -1; i <= 1; i++) {
            float wx = alongZ ? edgeX : edgeX + i * 1.0f;
            float wz = alongZ ? edgeZ + i * 1.0f : edgeZ;
            for (int y = 0; y < WALL_HEIGHT; y++) {
                r.pieces.add(piece(Piece.PieceType.BlockStone, wx, ground + 0.5f + y, wz,
                        0, Piece.PieceColor.Natural));
            }
        }
    }

    private static void doorSide(Result r, boolean[][] open, int[][] roomId, int gx, int gz, int dx, int dz,
                                 float cx, float cz, float ground, int seed) {
        int nx = gx + dx, nz = gz + dz;
        if (nx < 0 || nx >= GRID || nz < 0 || nz >= GRID || !open[nx][nz]) return;
        int a = roomId[gx][gz], b = roomId[nx][nz];
        if (a == b) return; // same room or corridor-to-corridor: leave fully open
        float edgeX = cx + dx * (CELL / 2f), edgeZ = cz + dz * (CELL / 2f);
        boolean alongZ = dx != 0;
        float rot = alongZ ? 0f : 90f;
        r.pieces.add(piece(Piece.PieceType.Door, edgeX, ground + 0.9f, edgeZ, rot, Piece.PieceColor.Black));
        for (int i : new int[]{-1, 1}) { // frame the door within the 3-wide opening
            float wx = alongZ ? edgeX : edgeX + i * 1.0f;
            float wz = alongZ ? edgeZ + i * 1.0f : edgeZ;
            for (int y = 0; y < WALL_HEIGHT; y++) {
                r.pieces.add(piece(Piece.PieceType.BlockStone, wx, ground + 0.5f + y, wz,
                        0, Piece.PieceColor.Natural));
            }
        }
    }

    // =====================================================================
    // Population: braziers, spawners, map markers
    // =====================================================================

    private static void populate(Result r, List<int[]> rooms, boolean[][] open,
                                 float originX, float originZ, float ground, int seed) {
        Mob.Kind[] roster = { Mob.Kind.AHRIMAN, Mob.Kind.TONBERRY, Mob.Kind.ICE_WISP,
                               Mob.Kind.FIRE_SPRITE, Mob.Kind.NEEDLEKIN };
        for (int i = 1; i < rooms.size(); i++) { // skip the entrance room
            int[] room = rooms.get(i);
            float cx = originX + cellX(room[0]), cz = originZ + cellX(room[1]);
            boolean treasure = i == rooms.size() - 1;
            Mob.Kind kind = treasure ? Mob.Kind.TONBERRY : roster[(int) (hash(i, 600, seed) * roster.length)];
            Mob.Spawner s = new Mob.Spawner();
            s.pos = Helpers.newVector3(cx, ground + 0.5f, cz);
            s.kind = kind;
            s.interval = treasure ? 14f : 9f;
            s.maxAlive = treasure ? 1 : 2;
            s.spawnRadius = 4f;
            r.spawners.add(s);
            mark(r, treasure ? "Dungeon Vault" : "Dungeon Chamber",
                    treasure ? WorldMap.MarkerKind.TOMB : WorldMap.MarkerKind.OTHER, cx, cz);
        }

        // braziers along corridors: sparse, hash-gated so they don't crowd every cell
        for (int gx = 0; gx < GRID; gx++) {
            for (int gz = 0; gz < GRID; gz++) {
                if (!open[gx][gz]) continue;
                if (hash(gx, gz, seed) > 0.88f) {
                    float cx = originX + cellX(gx), cz = originZ + cellX(gz);
                    r.pieces.add(piece(Piece.PieceType.TechLight, cx, ground + 2.1f, cz,
                            0, Piece.PieceColor.Iron));
                }
            }
        }
    }
}
