package toyz.builder;

import org.bytedeco.javacpp.FloatPointer;
import org.bytedeco.javacpp.ShortPointer;

import com.raylib.Raylib.Mesh;
import com.raylib.Raylib.Model;

import static com.raylib.Raylib.*;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

/**
 * Export every in-game mesh for Blender 2.9.3 fix-up (texture, scale, rotation).
 *
 * Output: exports/meshes/
 *   pieces/*.obj  — procedural builder pieces
 *   glb/*.glb     — copies of assets/models
 *   manifest.txt
 *
 * Press F9 in-game (or call exportAll).
 */
public final class MeshExporter {

    public static final String OUT_ROOT = "exports/meshes";

    private MeshExporter() {}

    public static String exportAll(List<Piece.PieceDef> pieceDefs) {
        try {
            Path root = Paths.get(OUT_ROOT);
            Path piecesDir = root.resolve("pieces");
            Path glbDir = root.resolve("glb");
            Files.createDirectories(piecesDir);
            Files.createDirectories(glbDir);

            List<String> manifest = new ArrayList<>();
            manifest.add("# Toyz Builder mesh export — Blender 2.9.3");
            manifest.add("# Import OBJ or GLB, fix materials/scale/rotation, Export glTF 2.0 → assets/models/");
            manifest.add("");

            int pieceCount = 0;
            if (pieceDefs != null) {
                for (Piece.PieceDef def : pieceDefs) {
                    if (def == null || def.model == null || def.model.meshCount() < 1) continue;
                    String safe = sanitize(def.name != null ? def.name : String.valueOf(def.type));
                    if (def.defaultColor != null) safe = safe + "_" + def.defaultColor.name();
                    Path obj = piecesDir.resolve(safe + ".obj");
                    int tris = writeModelObj(def.model, obj.toFile(), safe);
                    if (tris > 0) {
                        manifest.add(String.format("PIECE\t%s\t%s\ttris=%d", safe, obj, tris));
                        pieceCount++;
                    }
                }
            }

            int glbCount = 0;
            Path assetsModels = Paths.get("assets/models");
            if (Files.isDirectory(assetsModels)) {
                File[] glbs = assetsModels.toFile().listFiles((d, n) -> {
                    String l = n.toLowerCase();
                    return l.endsWith(".glb") || l.endsWith(".gltf");
                });
                if (glbs != null) {
                    for (File g : glbs) {
                        Path dest = glbDir.resolve(g.getName());
                        Files.copy(g.toPath(), dest, StandardCopyOption.REPLACE_EXISTING);
                        manifest.add("GLB\t" + g.getName() + "\t" + dest);
                        glbCount++;
                    }
                }
            }

            Path man = root.resolve("manifest.txt");
            try (BufferedWriter w = Files.newBufferedWriter(man)) {
                w.write("pieces_exported=" + pieceCount);
                w.newLine();
                w.write("glb_copied=" + glbCount);
                w.newLine();
                for (String line : manifest) {
                    w.write(line);
                    w.newLine();
                }
            }

            String msg = "Exported " + pieceCount + " OBJs + " + glbCount + " GLBs → " + root.toAbsolutePath();
            System.out.println("[MeshExporter] " + msg);
            return msg;
        } catch (Exception e) {
            String err = "MeshExporter failed: " + e.getMessage();
            System.err.println(err);
            e.printStackTrace();
            return err;
        }
    }

    private static String sanitize(String name) {
        if (name == null || name.isEmpty()) return "unnamed";
        return name.replaceAll("[^a-zA-Z0-9_\\-]+", "_");
    }

    /** Wavefront OBJ from raylib Model (FloatPointer vertices, like Piece bake). */
    public static int writeModelObj(Model model, File outFile, String objectName) {
        if (model == null || model.meshCount() < 1) return -1;
        int totalTris = 0;
        try (BufferedWriter w = new BufferedWriter(new FileWriter(outFile))) {
            w.write("# Toyz Builder / Serif System Works");
            w.newLine();
            w.write("o " + objectName);
            w.newLine();

            int vertexOffset = 1;
            for (int mi = 0; mi < model.meshCount(); mi++) {
                Mesh mesh = model.meshes().position(mi);
                if (mesh == null || mesh.isNull()) continue;
                int vc = mesh.vertexCount();
                int tc = mesh.triangleCount();
                if (vc <= 0) continue;

                FloatPointer v = mesh.vertices();
                FloatPointer n = mesh.normals();
                FloatPointer uv = mesh.texcoords();
                if (v == null) continue;

                w.write("g mesh_" + mi);
                w.newLine();

                for (int i = 0; i < vc; i++) {
                    w.write(String.format("v %.6f %.6f %.6f",
                            v.get(i * 3L), v.get(i * 3L + 1), v.get(i * 3L + 2)));
                    w.newLine();
                }
                boolean hasUV = uv != null;
                if (hasUV) {
                    for (int i = 0; i < vc; i++) {
                        w.write(String.format("vt %.6f %.6f", uv.get(i * 2L), uv.get(i * 2L + 1)));
                        w.newLine();
                    }
                }
                boolean hasN = n != null;
                if (hasN) {
                    for (int i = 0; i < vc; i++) {
                        w.write(String.format("vn %.6f %.6f %.6f",
                                n.get(i * 3L), n.get(i * 3L + 1), n.get(i * 3L + 2)));
                        w.newLine();
                    }
                }

                int[] indices = buildIndices(mesh, tc, vc);
                for (int t = 0; t + 2 < indices.length; t += 3) {
                    int a = indices[t] + vertexOffset;
                    int b = indices[t + 1] + vertexOffset;
                    int c = indices[t + 2] + vertexOffset;
                    if (hasUV && hasN) {
                        w.write(String.format("f %d/%d/%d %d/%d/%d %d/%d/%d",
                                a, a, a, b, b, b, c, c, c));
                    } else if (hasN) {
                        w.write(String.format("f %d//%d %d//%d %d//%d", a, a, b, b, c, c));
                    } else if (hasUV) {
                        w.write(String.format("f %d/%d %d/%d %d/%d", a, a, b, b, c, c));
                    } else {
                        w.write(String.format("f %d %d %d", a, b, c));
                    }
                    w.newLine();
                    totalTris++;
                }
                vertexOffset += vc;
            }
        } catch (IOException e) {
            System.err.println("[MeshExporter] " + outFile + ": " + e.getMessage());
            return -1;
        }
        return totalTris;
    }

    private static int[] buildIndices(Mesh mesh, int triangleCount, int vertexCount) {
        int need = Math.max(triangleCount * 3, 0);
        if (need <= 0) {
            int[] seq = new int[vertexCount];
            for (int i = 0; i < vertexCount; i++) seq[i] = i;
            return seq;
        }
        try {
            ShortPointer idx = mesh.indices();
            if (idx != null && !idx.isNull()) {
                int[] out = new int[need];
                for (int i = 0; i < need; i++) {
                    out[i] = idx.get(i) & 0xFFFF;
                }
                return out;
            }
        } catch (Throwable t) {
            // fall through to sequential
        }
        int[] seq = new int[need];
        for (int i = 0; i < need; i++) seq[i] = i;
        return seq;
    }
}
